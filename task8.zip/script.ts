import { Client, Databases } from 'node-appwrite';
import * as fs from 'fs';

const envContent = fs.readFileSync('/app/.dev.env.json', 'utf8');
const env = JSON.parse(envContent);

const client = new Client()
  .setEndpoint(env.VITE_APPWRITE_ENDPOINT || 'https://fra.cloud.appwrite.io/v1')
  .setProject(env.VITE_APPWRITE_PROJECT_ID)
  .setKey(env.APPWRITE_API_KEY);

const databases = new Databases(client);

async function run() {
  console.log('--- LISTING ALL DATABASES ---');
  try {
    const list = await databases.list();
    console.log(`Found ${list.total} databases:`);
    for (const d of list.databases) {
      console.log(`- Database: ${d.name}, ID: ${d.$id}`);
      try {
        const cols = await databases.listCollections(d.$id);
        console.log(`  Collections (${cols.total}):`);
        for (const c of cols.collections) {
          console.log(`    * ${c.name} (${c.$id})`);
        }
      } catch (e: any) {
        console.log(`  Error listing collections: ${e.message}`);
      }
    }
  } catch (err: any) {
    console.error('Failed listing databases:', err.message);
  }
}

run();
