/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { 
  User, 
  Task, 
  KPIs, 
  Notification, 
  TaskStatus, 
  Department, 
  TaskActivityLog, 
  AiKpiLog, 
  TaskRiskScore, 
  EmployeeWorkload 
} from '../types';
import { DB } from '../lib/dataStore';
import { 
  Sparkles, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  Calendar,
  Send, 
  BellRing, 
  Activity, 
  FileSpreadsheet,
  Workflow, 
  FileCheck,
  UserCheck2,
  RefreshCw,
  Search,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  UserPlus,
  Compass,
  ArrowRight,
  ShieldCheck,
  Flame,
  ShieldAlert,
  Users,
  Volume2,
  VolumeX
} from 'lucide-react';

interface DashboardProps {
  currentUser: User;
  onSetTab: (tab: string) => void;
  tasks: Task[];
  setTasks: (tasks: Task[]) => void;
  notifications: Notification[];
  setNotifications: (notifs: Notification[]) => void;
  kpis: KPIs[];
}

export default function Dashboard({ 
  currentUser, 
  onSetTab, 
  tasks, 
  setTasks, 
  notifications, 
  setNotifications, 
  kpis 
}: DashboardProps) {
  const [aiInsight, setAiInsight] = useState('');
  const [loadingInsight, setLoadingInsight] = useState(false);
  
  // Natural Language Search states
  const [searchQuery, setSearchQuery] = useState('');
  const [activeQuickFilter, setActiveQuickFilter] = useState<'all' | 'vivian' | 'overdue' | 'technical'>('all');

  const [isMuted, setIsMuted] = useState<boolean>(() => {
    return localStorage.getItem('tindan_mute_notifications') === 'true';
  });

  const toggleMute = () => {
    const newValue = !isMuted;
    setIsMuted(newValue);
    localStorage.setItem('tindan_mute_notifications', String(newValue));
  };

  // Trigger sound effect auxiliary
  const playSoundEffect = () => {
    const muted = localStorage.getItem('tindan_mute_notifications') === 'true';
    if (muted) return;
    try {
      const audio = document.getElementById('bell-sound-ai') as HTMLAudioElement;
      if (audio) {
        audio.currentTime = 0;
        audio.play().catch(e => console.log('Audio autoplay blocked'));
      }
    } catch (err) {}
  };

  // 1. Fetching upgraded AI collection tables from local storage
  const [activityLogs, setActivityLogs] = useState<TaskActivityLog[]>([]);
  const [kpiLogs, setKpiLogs] = useState<AiKpiLog[]>([]);
  const [riskScores, setRiskScores] = useState<TaskRiskScore[]>([]);
  const [workloads, setWorkloads] = useState<EmployeeWorkload[]>([]);

  const loadUpgradedCollections = async () => {
    const [logs, kpis, risks, loads] = await Promise.all([
      DB.getActivityLogs(),
      DB.getAiKpiLogs(),
      DB.getTaskRiskScores(),
      DB.getEmployeeWorkloads()
    ]);
    setActivityLogs(logs);
    setKpiLogs(kpis);
    setRiskScores(risks);
    setWorkloads(loads);
  };

  useEffect(() => {
    loadUpgradedCollections();
    // Removed fetchAiInsights(true) to save tokens as per customer request.
    // Diagnosis is now manual trigger via the action button.
  }, [tasks.length]); // Use length to avoid excessive triggers if task objects are recreated

  const fetchAiInsights = async (isInitial = false) => {
    setLoadingInsight(true);
    try {
      const targetTasks = tasks.filter(t => {
        const isControlRole = currentUser.id === '1' ||
          currentUser.role === 'Super Admin' ||
          currentUser.role === 'Admin' ||
          currentUser.role?.includes('CEO') ||
          currentUser.role?.includes('Quản lý');
        if (isControlRole) return true;
        if (currentUser.role === 'Manager') return t.department === currentUser.department;
        return t.assignee.toLowerCase().includes(currentUser.name.toLowerCase().split(' ')[0].toLowerCase());
      });

      const res = await fetch('/api/ai/generate-summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          tasks: targetTasks.map(t => ({ title: t.title, assignee: t.assignee, status: t.status, priority: t.priority, overdueRisk: t.overdueRisk })), 
          kpis 
        })
      });
      const data = await res.json();
      if (data.success) {
        setAiInsight(data.summary);
      } else {
        setAiInsight("Không thể kết nối đến máy chủ AI Tín Dân trực tuyến. Hiện tại đang kích hoạt Chẩn Đoán Trì hoãn Ngoại tuyến.");
      }
    } catch (e) {
      setAiInsight("Sự cố kênh truyền AI. Hiển thị dự báo KPI tối ưu hóa bảo ôn decal xưởng.");
    } finally {
      setLoadingInsight(false);
    }
  };

  // Helper action: Mark Done
  const handleMarkDone = async (taskId: string) => {
    playSoundEffect();
    const target = tasks.find(t => t.id === taskId);
    if (!target) return;

    const newStatus = target.status === TaskStatus.DONE ? TaskStatus.PENDING : TaskStatus.DONE;

    let changedTask: Task | null = null;
    const updated = tasks.map(t => {
      if (t.id === taskId) {
        changedTask = { ...t, status: newStatus };
        return changedTask;
      }
      return t;
    });
    setTasks(updated);
    if (changedTask) {
      await DB.saveTask(changedTask);
    }

    // Logging activity timeline
    const newLog = {
      id: 'al_add_' + Date.now(),
      taskId,
      taskTitle: target.title,
      userId: currentUser.id,
      userName: currentUser.name,
      actionType: 'status_change' as const,
      description: `Đã cập nhật trạng thái tác vụ thành ${newStatus === TaskStatus.DONE ? 'Hoàn thành' : 'Chưa xong'}.`,
      createdAt: new Date().toISOString()
    };
    await DB.saveActivityLog(newLog);
    setActivityLogs(prev => [newLog, ...prev]);

    if (newStatus === TaskStatus.DONE) {
      const newNotif: Notification = {
        id: 'new_notif_' + Date.now(),
        title: 'Hoàn thành công việc',
        content: `Chúc mừng! Tác vụ "${target.title}" đã gán về đích an toàn. KPI +${target.kpiScore}đ tích lũy!`,
        type: 'task',
        createdAt: new Date().toISOString(),
        read: false
      };
      await DB.saveNotification(newNotif);
      setNotifications([newNotif, ...notifications]);
    }
  };

  // Helper action: Force Extend Deadline (+3 Days)
  const handleExtendDeadline = async (taskId: string) => {
    playSoundEffect();
    const target = tasks.find(t => t.id === taskId);
    if (!target) return;

    // Add 3 days to original or current date
    const origDate = new Date(target.deadline || '2026-06-12');
    origDate.setDate(origDate.getDate() + 3);
    const newDeadlineStr = origDate.toISOString().split('T')[0];

    let changedTask: Task | null = null;
    const updated = tasks.map(t => {
      if (t.id === taskId) {
        changedTask = { ...t, deadline: newDeadlineStr, overdueRisk: false };
        return changedTask;
      }
      return t;
    });
    setTasks(updated);
    if (changedTask) {
      await DB.saveTask(changedTask);
    }

    // Filter out risk score warnings
    const riskData = await DB.getTaskRiskScores();
    const fixedRisk = riskData.filter(r => r.taskId !== taskId);
    await DB.saveTaskRiskScores(fixedRisk);
    setRiskScores(fixedRisk);

    const newLog = {
      id: 'al_ext_' + Date.now(),
      taskId,
      taskTitle: target.title,
      userId: currentUser.id,
      userName: currentUser.name,
      actionType: 'ai_action' as const,
      description: `Gia hạn thành công thêm 3 ngày (Hạn chót mới: ${newDeadlineStr}) theo chỉ báo tránh nghẽn xưởng in.`,
      createdAt: new Date().toISOString()
    };
    await DB.saveActivityLog(newLog);
    setActivityLogs(prev => [newLog, ...prev]);

    // Notify sếp
    const newNotif: Notification = {
      id: 'new_notif_' + Date.now(),
      title: 'Đã Gia Hạn Thông Minh',
      content: `Robot Tín Dân tự động điều chỉnh hạn chót cho "${target.title}" tới ${newDeadlineStr} để giảm áp tải cho nhân sự.`,
      type: 'ai',
      createdAt: new Date().toISOString(),
      read: false
    };
    setNotifications([newNotif, ...notifications]);
    await DB.saveNotification(newNotif);
  };

  // Master clear alerts center
  const clearAllNotifications = () => {
    setNotifications([]);
    DB.saveNotifications([]);
  };

  // ==========================================
  // NATURAL LANGUAGE SEARCH FILTERING ENGINE
  // ==========================================
  const getFilteredTasks = () => {
    let list = tasks;

    // 1. Role-based view protection
    const isControlRole = currentUser.id === '1' ||
      currentUser.role === 'Super Admin' ||
      currentUser.role === 'Admin' ||
      currentUser.role?.includes('CEO') ||
      currentUser.role?.includes('Quản lý');
    
    if (!isControlRole) {
      if (currentUser.role === 'Manager') {
        list = list.filter(t => t.department === currentUser.department);
      } else {
        list = list.filter(t => t.assignee.toLowerCase().includes(currentUser.name.toLowerCase().split(' ')[0].toLowerCase()));
      }
    }

    // 2. Active quick headers button filters
    if (activeQuickFilter === 'vivian') {
      list = list.filter(t => t.title.toLowerCase().includes('vivian') || t.projectName.toLowerCase().includes('vivian'));
    } else if (activeQuickFilter === 'overdue') {
      list = list.filter(t => {
        const today = '2026-06-04';
        return t.status !== TaskStatus.DONE && (t.deadline < today || t.overdueRisk);
      });
    } else if (activeQuickFilter === 'technical') {
      list = list.filter(t => t.department === Department.KY_THUAT);
    }

    // 3. AI Smart NLP text search parse
    if (searchQuery.trim().length > 0) {
      const q = searchQuery.toLowerCase().trim();

      // Heuristics mapping natural queries to tags
      if (q.includes('quá hạn') || q.includes('overdue') || q.includes('trễ')) {
        return list.filter(t => t.status !== TaskStatus.DONE && t.deadline < '2026-06-04');
      }
      if (q.includes('khẩn cấp') || q.includes('high') || q.includes('gấp')) {
        return list.filter(t => t.priority === 'High');
      }
      if (q.includes('marketing') || q.includes('ads') || q.includes('truyền thông')) {
        return list.filter(t => t.department === Department.MARKETING || t.title.toLowerCase().includes('ads') || t.title.toLowerCase().includes('banner'));
      }
      if (q.includes('kỹ thuật') || q.includes('in') || q.includes('máy')) {
        return list.filter(t => t.department === Department.KY_THUAT || t.title.toLowerCase().includes('máy') || t.title.toLowerCase().includes('uv'));
      }
      if (q.includes('hải') || q.includes('cskh')) {
        return list.filter(t => t.assignee.includes('Hải'));
      }
      if (q.includes('đức') || q.includes('bảo dưỡng')) {
        return list.filter(t => t.assignee.includes('Đức'));
      }
      if (q.includes('nam') || q.includes('facebook')) {
        return list.filter(t => t.assignee.includes('Nam'));
      }

      // Default string match
      return list.filter(t => 
        t.title.toLowerCase().includes(q) || 
        t.description.toLowerCase().includes(q) ||
        t.assignee.toLowerCase().includes(q) ||
        t.department.toLowerCase().includes(q)
      );
    }

    return list;
  };

  const processedTasksList = getFilteredTasks();
  const todayTasks = processedTasksList.filter(t => t.status !== TaskStatus.DONE);
  const finishedTasks = processedTasksList.filter(t => t.status === TaskStatus.DONE);
  const overdueTasks = processedTasksList.filter(t => {
    const today = '2026-06-04';
    return t.status !== TaskStatus.DONE && (t.deadline < today || t.overdueRisk);
  });

  const completedPercentage = Math.round((finishedTasks.length / (processedTasksList.length || 1)) * 100);

  // ==========================================
  // AI CHECK DONE DETECTION ENGINE (Heuristic Feature 2)
  // Find tasks with high checklist percentage but status is NOT DONE
  // ==========================================
  const getTasksNeedingCheckDoneAlert = () => {
    return tasks.filter(t => {
      if (t.status === TaskStatus.DONE) return false;
      if (!t.checklist || t.checklist.length === 0) return false;
      
      const doneItems = t.checklist.filter(item => item.done).length;
      const ratio = doneItems / t.checklist.length;
      
      // Warn if 60%+ checklist items are marked done, but task status is still pending
      return ratio >= 0.6;
    });
  };

  const checkDoneAlerts = getTasksNeedingCheckDoneAlert();

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-4 md:p-6 lg:p-8 font-sans">
      
        {/* Simple Search Header Bar */}
        <div className="glass-card rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="relative w-full md:max-w-md">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-400">
              <Search className="w-4 h-4 text-blue-500" />
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder='Tìm kiếm nhiệm vụ, dự án, nhân viên...'
              className="w-full text-xs pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 dark:text-white glass-input focus:outline-none"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute inset-y-0 right-0 flex items-center pr-3.5 text-[10px] uppercase font-bold text-slate-400 hover:text-rose-500"
              >
                Xóa
              </button>
            )}
          </div>
        </div>

      {/* 🔔 FEATURE 2: AI CHECK-DONE FORGOTTEN REMINDER */}
      {checkDoneAlerts.length > 0 && (
        <div className="bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 p-4 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-pulse">
          <div className="flex items-start gap-2.5">
            <span className="p-2 bg-emerald-500/20 text-emerald-600 rounded-xl mt-0.5">
              <ShieldCheck className="w-5 h-5 text-emerald-500" />
            </span>
            <div>
              <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider block">AI Tự Động Định Vị Hoàn Tất</span>
              <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 mt-1">
                Có phải sếp đã hoàn thành việc: "{checkDoneAlerts[0].title}"?
              </h4>
              <p className="text-[10.5px] text-slate-450 leading-relaxed mt-1">
                Hệ thống nhận thấy <b>{checkDoneAlerts[0].checklist?.filter(i => i.done).length} / {checkDoneAlerts[0].checklist?.length}</b> checklist của nhân sự đã gạt tích xanh hoàn chỉnh.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 self-end sm:self-auto text-[10.5px]">
            <button
              onClick={() => handleMarkDone(checkDoneAlerts[0].id)}
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer"
            >
              Nộp Đóng Việc
            </button>
            <button
              onClick={() => handleExtendDeadline(checkDoneAlerts[0].id)}
              className="bg-white/5 border border-white/10 hover:bg-white/10 text-slate-350 px-2.5 py-1.5 rounded-lg font-bold cursor-pointer"
            >
              Gia Hạn Thêm
            </button>
          </div>
        </div>
      )}

      {/* Visual greeting top summary card */}
      <div className="glass-card rounded-2xl p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-2xl">👋</span>
            <h1 className="text-xl md:text-2xl font-bold font-display text-slate-900 dark:text-white">
              Chào mừng, {currentUser.name}! 🚀
            </h1>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
            Hệ thống đang đồng bộ với <span className="font-semibold text-blue-600 dark:text-blue-400">Tín Dân Company</span> • Trợ lý AI đang quản trị <b>{workloads.length} nhân sự</b> và <b>{tasks.length} đầu việc</b>.
          </p>
        </div>

        {/* Sync trigger button */}
        <button
          onClick={() => fetchAiInsights(false)}
          className="flex items-center gap-1.5 px-3.5 py-2.5 text-xs text-white bg-blue-600 hover:bg-blue-700 font-bold rounded-xl transition-all cursor-pointer shadow-lg glowing-btn-blue-ai"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loadingInsight ? 'animate-spin' : ''}`} />
          <span>Kích hoạt AI Chẩn Đoán</span>
        </button>
      </div>

      {/* Grid of counter cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        
        <div className="glass-card rounded-2xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-widest block font-bold font-mono">Cần hoàn thành</span>
            <span className="text-2xl font-bold text-slate-800 dark:text-white mt-1 block">{todayTasks.length}</span>
            <span className="text-[10px] text-slate-400 mt-1 block">Tác vụ đang mở</span>
          </div>
          <div className="p-2.5 bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 rounded-xl">
            <Clock className="w-5 h-5 animate-pulse" />
          </div>
        </div>

        <div className="glass-card rounded-2xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-widest block font-bold font-mono">Trễ nải & rủi ro</span>
            <span className="text-2xl font-bold text-red-600 mt-1 block">{overdueTasks.length}</span>
            <span className="text-[10px] text-slate-400 mt-1 block">Chậm tiến độ mục tiêu</span>
          </div>
          <div className="p-2.5 bg-red-500/10 text-red-650 dark:text-red-400 rounded-xl">
            <AlertTriangle className="w-5 h-5 animate-bounce" />
          </div>
        </div>

        <div className="glass-card rounded-2xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-widest block font-bold font-mono">Tỷ lệ hoàn thành</span>
            <span className="text-2xl font-bold text-slate-800 dark:text-white mt-1 block">{completedPercentage}%</span>
            <div className="w-20 bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
              <div className="bg-emerald-500 h-full transition-all" style={{ width: `${completedPercentage}%` }} />
            </div>
          </div>
          <div className="p-2.5 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-xl">
            <CheckCircle className="w-5 h-5" />
          </div>
        </div>

        <div className="glass-card rounded-2xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-widest block font-bold font-mono">Doanh thu tích lũy KPI</span>
            <span className="text-2xl font-bold text-slate-800 dark:text-white mt-1 block">
              {processedTasksList.filter(t => t.status === TaskStatus.DONE).reduce((acc, t) => acc + t.kpiScore, 0)}đ
            </span>
            <span className="text-[10px] text-slate-400 mt-1 block">Tỉ điểm ghi nhận Q2</span>
          </div>
          <div className="p-2.5 bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-xl">
            <Activity className="w-5 h-5" />
          </div>
        </div>

      </div>

      {/* Main split grid: AI insights diagnostics & tasks / logs */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Hand: AI Intelligence diagnostics summary */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* AI Insights terminal panel */}
          <div className="glass-card rounded-2xl overflow-hidden">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-4 text-white flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-yellow-300 fill-yellow-300" />
                <span className="font-display font-bold text-sm tracking-tight">TÍN DÂN EXECUTIVE AI CO-PILOT CHẨN ĐOÁN THỜI GIAN THỰC</span>
              </div>
              <span className="text-[9px] bg-white/20 px-2 py-0.5 rounded-full font-mono">Gemini 3.5 Engine</span>
            </div>

            <div className="p-5 font-sans leading-relaxed text-slate-700 dark:text-slate-300 text-sm whitespace-pre-line sm:max-h-[380px] overflow-y-auto">
              {loadingInsight ? (
                <div className="py-12 flex flex-col items-center justify-center gap-3 text-slate-400">
                  <RefreshCw className="w-8 h-8 animate-spin text-blue-500" />
                  <p className="text-xs font-mono">Đang quét toàn bộ dữ liệu xưởng Tem Vivian, vẽ bản đồ KPI nhân sự...</p>
                </div>
              ) : (
                <div className="prose dark:prose-invert max-w-none text-slate-800 dark:text-slate-200">
                  {aiInsight || "Tài khoản của sếp chưa tải dữ liệu chẩn đoán AI hoặc kết nối bị dán đoạn. Hãy nhấn 'Kích hoạt AI Chẩn Đoán' ở thanh góc trên để nhận thông tin ngay lập tức."}
                </div>
              )}
            </div>

            <div className="bg-white/5 dark:bg-black/10 border-t border-slate-200/50 dark:border-white/5 p-3 px-4 flex justify-between items-center text-xs text-slate-500 dark:text-slate-400">
              <div className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-blue-500" />
                <span>Số liệu dựa trên tất cả Dự Án hoành động</span>
              </div>
              <span>Miễn phí token bởi AI Studio Build</span>
            </div>
          </div>

          {/* ☀️ FEATURE 4: AI NEXT DAY PRIORITY SUGGESTIONS */}
          <div className="glass-card rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Compass className="w-4 h-4 text-blue-500" />
                <h3 className="text-sm font-bold font-display uppercase text-slate-800 dark:text-white">AI Khuyến Nghị Ưu Tiên Ngày Mai</h3>
              </div>
              <span className="text-[9px] bg-blue-500/10 text-blue-500 px-2 py-0.5 rounded-full font-bold">Thần tốc - Tối ưu</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {(() => {
                const recommendedTasks = tasks
                  .filter(t => t.status !== 'Done' && t.status !== 'Pending')
                  .sort((a, b) => {
                    const prioScore = (p: string) => p === 'High' ? 3 : p === 'Medium' ? 2 : 1;
                    if (prioScore(a.priority) !== prioScore(b.priority)) {
                      return prioScore(b.priority) - prioScore(a.priority);
                    }
                    return new Date(a.deadline).getTime() - new Date(b.deadline).getTime();
                  });

                if (recommendedTasks.length === 0) {
                  return (
                    <div className="p-3.5 bg-white/5 border border-white/5 rounded-xl space-y-1.5 text-xs col-span-2 text-center text-slate-500 dark:text-slate-400">
                      ✨ Tất cả công việc ưu tiên đều đã hoàn thành xuất sắc! Hệ thống đề xuất sếp chuẩn bị chiến dịch mới hoặc rà soát xưởng.
                    </div>
                  );
                }

                return recommendedTasks.slice(0, 2).map((t) => {
                  const dayColor = t.priority === 'High' ? 'bg-rose-500' : 'bg-amber-500';
                  const pText = t.title.toLowerCase();
                  let aiReason = t.description || `Công việc thuộc phòng ban ${t.department}. Cần theo sát nhân sự ${t.assignee} để hoàn thành đúng tiến độ.`;
                  if (pText.includes('decal') || pText.includes('vivian') || pText.includes('in') || pText.includes('uv')) {
                    aiReason = `Lô Decal của Vivian có tỷ lệ đóng góp KPI doanh số cao. Cần theo sát ${t.assignee} vận hành lò bảo ôn UV chính gốc.`;
                  } else if (pText.includes('ads') || pText.includes('facebook') || pText.includes('marketing') || pText.includes('lead')) {
                    aiReason = `Lead đầu tuần đổ về tốt, cần ${t.assignee} rà soát chi phí thầu quảng cáo để tối ưu hóa ROI và CPL sản xuất.`;
                  }

                  const formatDeadline = (dateStr: string) => {
                    if (!dateStr) return '';
                    try {
                      const d = new Date(dateStr);
                      if (isNaN(d.getTime())) return dateStr;
                      return `${d.getDate()}/${d.getMonth() + 1}`;
                    } catch {
                      return dateStr;
                    }
                  };

                  return (
                    <div key={t.id} className="p-3.5 bg-white/5 border border-white/5 rounded-xl space-y-1.5 text-xs">
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-slate-800 dark:text-white flex items-center gap-1.5 truncate max-w-[70%]">
                          <span className={`w-2 h-2 rounded-full shrink-0 ${dayColor}`} />
                          <span className="truncate">{t.title}</span>
                        </span>
                        <span className="text-[9px] text-slate-400 font-mono shrink-0">Hạn {formatDeadline(t.deadline)}</span>
                      </div>
                      <p className="text-[10.5px] text-slate-500 dark:text-slate-400 leading-relaxed line-clamp-2">
                        {aiReason}
                      </p>
                    </div>
                  );
                });
              })()}
            </div>
          </div>

          {/* 🔥 FEATURE 5 & 14: AI BOTTLENECK DETECTION & RISK TASKS */}
          <div className="glass-card rounded-2xl p-5 space-y-4">
            <div className="flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-red-500 animate-pulse" />
              <h3 className="text-sm font-bold font-display uppercase text-slate-800 dark:text-white">Cơ Nguy Cặp Trì Hoãn & Điểm Nghẽn AI Phát Hiện</h3>
            </div>

            <div className="space-y-3.5">
              {riskScores.map(risk => {
                const assignedTask = tasks.find(t => t.id === risk.taskId);
                return (
                  <div key={risk.id} className="p-4 bg-red-550/5 border border-red-500/15 rounded-xl space-y-3 text-xs">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="px-1.5 py-0.5 rounded bg-red-600 text-[9px] font-bold text-white uppercase">
                          Nguy cơ {risk.riskScore}%
                        </span>
                        <h4 className="font-bold text-slate-800 dark:text-white">{risk.taskTitle}</h4>
                      </div>
                      <span className="text-[10px] text-slate-400">Chịu trách nhiệm: <b>{assignedTask?.assignee || 'Trần Minh Đức'}</b></span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-[11px] leading-relaxed">
                      <div>
                        <span className="text-red-500 font-bold block mb-0.5">⚠️ Nguyên do kẹt dồn:</span>
                        <p className="text-slate-500 dark:text-slate-350">{risk.reason}</p>
                      </div>
                      <div>
                        <span className="text-emerald-500 font-bold block mb-0.5">💡 Phương giải AI kiến đề:</span>
                        <p className="text-slate-500 dark:text-slate-350">{risk.solution}</p>
                      </div>
                    </div>

                    <div className="flex justify-end gap-1.5 mt-1 border-t border-white/5 pt-2">
                      <button
                        onClick={() => handleExtendDeadline(risk.taskId)}
                        className="text-[10px] bg-blue-600/20 text-blue-500 hover:bg-blue-600/30 px-2.5 py-1 rounded font-bold cursor-pointer"
                      >
                        Bù hạn chót +3 Ngày (Không nghẽn)
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 📊 FEATURE 12: WEEKLY KPI SCORE TREND ANALYSIS & RANKING */}
          <div className="glass-card rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <UserCheck2 className="w-4 h-4 text-emerald-500" />
                <h3 className="text-sm font-bold font-display uppercase text-slate-800 dark:text-white">Kiểm định KPI Nhân Sự & Biểu đồ Xu Hướng</h3>
              </div>
            </div>

            <div className="space-y-4">
              {kpiLogs.map(log => (
                <div key={log.id} className="p-3 bg-white/5 border border-white/5 rounded-xl space-y-2 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-slate-800 dark:text-white flex items-center gap-2">
                      <span>{log.userName}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/5 text-slate-400 font-light">{log.department}</span>
                    </span>
                    <span className="text-blue-500 font-bold">Thành tích: {log.completionScore}đ</span>
                  </div>

                  <div className="grid grid-cols-4 gap-2 text-center text-[10px] py-1 border-y border-white/5">
                    {log.weeklyKPIs.map((score, i) => (
                      <div key={i}>
                        <span className="text-slate-500 block text-[9px]">Tuần {i+1}</span>
                        <span className="font-bold text-slate-700 dark:text-slate-200">{score}đ</span>
                      </div>
                    ))}
                  </div>

                  <div className="text-[10px] text-slate-450 leading-relaxed italic flex items-start gap-1">
                    <span className="text-emerald-500 font-bold shrink-0">AI khuyên:</span>
                    <span>"{log.suggestions[0]}"</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Right Hand: Today's Tasks Checklist & Alert Log */}
        <div className="lg:col-span-5 space-y-6">
          
{/* Today Tasks Scannable Column with Smart Deadlines Evaluation */}
          <div className="glass-card rounded-2xl p-5 space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-sm font-bold font-display text-slate-800 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                <span>Nhiệm vụ trực thuộc</span>
                <span className="px-2 py-0.5 rounded-full bg-blue-500/10 text-[10px] text-blue-500 font-bold">
                  {todayTasks.length}
                </span>
              </h2>
              <button
                onClick={() => onSetTab('tasks')}
                className="text-xs text-blue-600 dark:text-blue-400 hover:underline font-semibold"
              >
                Kanban
              </button>
            </div>

            <div className="space-y-3 max-h-[310px] overflow-y-auto pr-1">
              {todayTasks.length === 0 ? (
                <div className="py-12 text-center text-slate-400 border border-dashed border-slate-200 dark:border-slate-850 rounded-xl space-y-2">
                  <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto animate-pulse" />
                  <p className="text-xs">Sạch sẽ! Không còn tác vụ chậm tồn.</p>
                </div>
              ) : (
                todayTasks.map((task) => {
                  const checkDoneDetected = checkDoneAlerts.some(c => c.id === task.id);
                  return (
                    <div
                      key={task.id}
                      className={`p-3 rounded-xl border transition-all ${
                        task.overdueRisk 
                          ? 'border-red-500 bg-red-500/5'
                          : 'border-slate-200 dark:border-white/5 hover:bg-white/5'
                      }`}
                    >
                      <div className="flex items-start gap-2.5">
                        <input
                          type="checkbox"
                          checked={task.status === 'Done'}
                          onChange={() => handleMarkDone(task.id)}
                          className="w-4 h-4 cursor-pointer mt-0.5 accent-blue-600 border-slate-300 rounded"
                        />
                        <div className="flex-1 min-w-0">
                          <span className="text-xs font-bold text-slate-800 dark:text-white block truncate">{task.title}</span>
                          
                          {/* Checklist mini indicator */}
                          {task.checklist && task.checklist.length > 0 && (
                            <div className="text-[10px] text-slate-400 mt-1 flex items-center gap-1 font-semibold">
                              <span>Checklist:</span>
                              <span className="text-blue-500">{task.checklist.filter(i => i.done).length}/{task.checklist.length}</span>
                              {checkDoneDetected && <span className="text-emerald-500 px-1 rounded bg-emerald-500/10 text-[9px] animate-pulse">Phát hiện xong!</span>}
                            </div>
                          )}

                          <div className="flex items-center justify-between gap-2 mt-2">
                            <span className="text-[9px] text-slate-400 font-bold block bg-white/5 px-2 py-0.5 rounded">Giao: <b>{task.assignee}</b></span>
                            <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1 font-semibold">
                              <Calendar className="w-3 h-3 text-blue-500" />
                              {task.deadline}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* System Notification bell-ringer center */}
          <div className="glass-card rounded-2xl p-5 space-y-4">
            <div className="flex justify-between items-center gap-2 flex-wrap">
              <h2 className="text-sm font-bold font-display text-slate-800 dark:text-white uppercase tracking-wider flex items-center gap-2">
                <BellRing className="w-4 h-4 text-amber-500 animate-bounce" />
                <span>Hoạt Động Kênh Chuyền Thông</span>
                {notifications.some(n => !n.read) && (
                  <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                )}
              </h2>
              <div className="flex items-center gap-2.5">
                <button
                  onClick={toggleMute}
                  title={isMuted ? "Bật chuông thông báo" : "Tắt chuông thông báo"}
                  className="p-1 px-1.5 text-slate-550 bg-slate-100 hover:bg-slate-200 dark:bg-white/5 dark:hover:bg-white/10 rounded-lg transition-all cursor-pointer border-none flex items-center gap-1 text-[10px] font-semibold"
                >
                  {isMuted ? (
                    <>
                      <VolumeX className="w-3.5 h-3.5 text-rose-500" />
                      <span className="text-rose-500">Đang Tắt</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
                      <span>Đang Bật</span>
                    </>
                  )}
                </button>
                {notifications.some(n => !n.read) && (
                  <button
                    onClick={async () => {
                      const updated = notifications.map(n => ({ ...n, read: true }));
                      setNotifications(updated);
                      await DB.saveNotifications(updated);
                    }}
                    className="text-[10.5px] text-blue-600 dark:text-blue-450 hover:underline font-bold"
                  >
                    Đọc tất cả
                  </button>
                )}
                {notifications.length > 0 && (
                  <button
                    onClick={clearAllNotifications}
                    className="text-[10.5px] text-rose-550 hover:underline font-medium"
                  >
                    Xóa log
                  </button>
                )}
              </div>
            </div>

            <div className="space-y-3 max-h-[190px] overflow-y-auto pr-1 text-xs">
              {notifications.length === 0 ? (
                <div className="py-6 text-center text-slate-400">
                  <p className="text-xs">Không có thông báo chưa đọc.</p>
                </div>
              ) : (
                notifications.map((notif) => (
                  <div
                    key={notif.id}
                    className="p-3 bg-slate-50/50 dark:bg-white/5 rounded-xl space-y-1 text-xs border border-slate-100/50 dark:border-white/5"
                  >
                    <div className="flex justify-between items-start">
                      <span className="font-semibold text-slate-800 dark:text-white font-display text-[11px]">{notif.title}</span>
                      <span className="text-[9px] text-slate-400 dark:text-slate-550 font-mono">
                        {new Date(notif.createdAt).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-300 text-[10.5px] leading-relaxed">{notif.content}</p>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* 📈 FEATURE 21: AI ACTIVITY TIMELINE (HISTORIC LOGGER) */}
          <div className="glass-card rounded-2xl p-5 space-y-4">
            <div className="flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-purple-500 animate-pulse" />
              <h3 className="text-sm font-bold font-display uppercase text-slate-800 dark:text-white">Dòng Lịch Sử Vận Hành Thời Gian Thực</h3>
            </div>

            <div className="relative pl-4 border-l-2 border-slate-200 dark:border-white/10 space-y-5 max-h-52 overflow-y-auto pr-1">
              {activityLogs.map(log => {
                let badgeClr = 'bg-blue-500';
                if (log.actionType === 'create') badgeClr = 'bg-emerald-500';
                if (log.actionType === 'status_change') badgeClr = 'bg-amber-500';
                if (log.actionType === 'ai_action') badgeClr = 'bg-purple-600';

                return (
                  <div key={log.id} className="relative text-xs">
                    {/* Ring dot icon decoration */}
                    <span className={`absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full ring-4 ring-white dark:ring-slate-900 ${badgeClr}`} />
                    
                    <div className="flex justify-between text-[10px] text-slate-400 font-mono mb-1">
                      <span>• {log.userName}</span>
                      <span>{new Date(log.createdAt).toLocaleDateString('vi-VN')} {new Date(log.createdAt).toLocaleTimeString('vi-VN', {hour: '2-digit', minute:'2-digit'})}</span>
                    </div>
                    
                    <span className="font-bold text-slate-800 dark:text-white">{log.taskTitle}</span>
                    <p className="text-slate-500 dark:text-slate-350 text-[10.5px] mt-0.5 leading-relaxed">{log.description}</p>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
