/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Custom updated KPI Manager by AI Studio Build
 */

import React, { useState, useEffect } from 'react';
import { User, KPIs, Department } from '../types';
import { DB } from '../lib/dataStore';
import { 
  Award, 
  TrendingUp, 
  Star, 
  FileDown, 
  Trash2, 
  Plus, 
  FileSpreadsheet, 
  Table
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';


interface KPIManagerProps {
  currentUser: User;
  kpis: KPIs[];
  setKpis: (kpis: KPIs[]) => void;
  onAddNotification: (title: string, content: string, type: string) => void;
}

export default function KPIManager({ currentUser, kpis, setKpis, onAddNotification }: KPIManagerProps) {
  const hasKpiAdminAccess = currentUser.id === '1' || 
    currentUser.role === 'Super Admin' || 
    currentUser.role === 'Admin' || 
    currentUser.role?.includes('CEO') || 
    currentUser.role?.includes('Quản lý');

  const [awardScore, setAwardScore] = useState<number>(10);
  const [selectedKpiId, setSelectedKpiId] = useState<string | null>(null);
  const [bonusComment, setBonusComment] = useState('');

  // Loaded employees list
  const [allUsers, setAllUsers] = useState<User[]>([]);
  
  // Custom dialog state for creating new KPI
  const [showAddKpiModal, setShowAddKpiModal] = useState(false);
  const [newKpiDept, setNewKpiDept] = useState<Department>(Department.MARKETING);
  const [newKpiUser, setNewKpiUser] = useState<string>('');
  const [newKpiMonth, setNewKpiMonth] = useState('06/2026');
  const [newKpiTotal, setNewKpiTotal] = useState<number>(10);
  const [newKpiCompleted, setNewKpiCompleted] = useState<number>(8);
  const [newKpiOverdue, setNewKpiOverdue] = useState<number>(1);
  const [newKpiScore, setNewKpiScore] = useState<number>(95);
  const [newKpiNotes, setNewKpiNotes] = useState('');

  // Load user data upon mounting
  useEffect(() => {
    DB.getUsers().then(users => {
      setAllUsers(users);
      // default the first user of chosen department
      const filtered = users.filter(u => u.department === newKpiDept);
      if (filtered.length > 0) {
        setNewKpiUser(filtered[0].name);
      }
    });
  }, []);

  // Sync chosen user list when department drop-down changes
  useEffect(() => {
    const filtered = allUsers.filter(u => u.department === newKpiDept);
    if (filtered.length > 0) {
      setNewKpiUser(filtered[0].name);
    } else {
      setNewKpiUser('');
    }
  }, [newKpiDept, allUsers]);

  const removeVietnameseTones = (str: string): string => {
    str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, "a");
    str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, "e");
    str = str.replace(/ì|í|ị|ỉ|ĩ/g, "i");
    str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, "o");
    str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, "u");
    str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, "y");
    str = str.replace(/đ/g, "d");
    str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, "A");
    str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, "E");
    str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, "I");
    str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, "O");
    str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, "U");
    str = str.replace(/Ỳ|Ý|Y|Ỷ|Ỹ/g, "Y");
    str = str.replace(/Đ/g, "D");
    return str;
  };

  const exportToExcel = () => {
    const workbook = XLSX.utils.book_new();

    // Create a summary sheet
    const summaryData = kpis.map(k => ({
      'Nhân sự': k.employeeName,
      'Phòng ban': k.department,
      'Tháng': k.month,
      'Tổng Task': k.totalTasks,
      'Hoàn thành': k.completedTasks,
      'Trễ hạn': k.overdueTasks,
      'Điểm KPI': k.kpiScore,
      'Ghi chú': k.notes
    }));
    const summarySheet = XLSX.utils.json_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(workbook, summarySheet, 'Tổng hợp KPI');

    // Create a sheet for each employee
    kpis.forEach(k => {
      const pList = k.weeklyProgress || [];
      const employeeData = [
        ['BÁO CÁO CHI TIẾT KPI NHÂN VIÊN'],
        ['Họ và tên:', k.employeeName || ''],
        ['Bộ phận:', k.department || ''],
        ['Tháng báo cáo:', k.month || ''],
        [''],
        ['Chỉ số chính', 'Giá trị'],
        ['Tổng số công việc', k.totalTasks ?? 0],
        ['Công việc hoàn thành', k.completedTasks ?? 0],
        ['Công việc trễ hạn', k.overdueTasks ?? 0],
        ['Điểm KPI tích lũy', k.kpiScore ?? 0],
        [''],
        ['Tiến độ tuần (1-4)'],
        ...pList.map((p, i) => [`Tuần ${i + 1}`, `${p}%`]),
        [''],
        ['Ghi chú/Đánh giá:', k.notes || '']
      ];
      const sheet = XLSX.utils.aoa_to_sheet(employeeData);
      const nameSafe = k.employeeName || 'KPI';
      const sheetName = nameSafe.substring(0, 30).replace(/[:\\\/\?\*\[\]]/g, '');
      XLSX.utils.book_append_sheet(workbook, sheet, sheetName || 'KPI');
    });

    XLSX.writeFile(workbook, `Bao_cao_KPI_Tin_Dan_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const exportToPDF = () => {
    try {
      const doc = new jsPDF();
      
      // Document header with green brand accent
      doc.setFontSize(18);
      doc.setTextColor(16, 185, 129); // Emerald Tín Dân
      doc.text(removeVietnameseTones('TIN DAN COMPANY - BAO CAO HIEU SUAT KPI'), 14, 20);
      
      doc.setFontSize(10);
      doc.setTextColor(100, 116, 139);
      doc.text(removeVietnameseTones(`Ngay lap bieu: ${new Date().toLocaleDateString('vi-VN')} | Chu ky: Thang 06/2026`), 14, 28);
      doc.text(removeVietnameseTones(`He dieu hanh quan tri hieu nang doanh nghiep Tin Dan OS`), 14, 34);
      
      // Define table headers and rows
      const tableColumn = ["STT", "Nhan su", "Phong ban", "Chu ky", "Tong viec", "Hoan thanh", "Tre han", "Diem KPI", "Ghi chu/Danh gia"];
      const tableRows = kpis.map((k, index) => [
        index + 1,
        removeVietnameseTones(k.employeeName || ''),
        removeVietnameseTones(k.department || ''),
        k.month || '',
        k.totalTasks ?? 0,
        k.completedTasks ?? 0,
        k.overdueTasks ?? 0,
        `${k.kpiScore ?? 0}d`,
        removeVietnameseTones(k.notes || 'Cong suat on dinh')
      ]);

      // Draw autoTable beautifully
      (doc as any).autoTable({
        head: [tableColumn],
        body: tableRows,
        startY: 40,
        theme: 'striped',
        headStyles: { fillColor: [16, 185, 129], fontStyle: 'bold' },
        styles: { fontSize: 8, font: 'helvetica' }
      });

      // Signature section
      const lastY = (doc as any).lastAutoTable.finalY + 18;
      doc.setFontSize(9);
      doc.setTextColor(100, 116, 139);
      doc.text(removeVietnameseTones('Hệ thống lập'), 20, lastY);
      doc.text(removeVietnameseTones(`${currentUser.name}`), 18, lastY + 12);

      doc.text(removeVietnameseTones('Phe duyet Quan ly tối cao (CEO)'), 135, lastY);
      doc.text(removeVietnameseTones('Tran Tuan Anh (Tin Dan)'), 137, lastY + 12);
      
      doc.save(`Bao_cao_KPI_Tin_Dan_${new Date().toISOString().split('T')[0]}.pdf`);
      
      onAddNotification(
        'Xuất file PDF hoàn tất',
        'Đã tải trữ thành công file báo cáo hiệu năng KPI điện tử (định dạng PDF tiêu chuẩn).',
        'system'
      );
    } catch (err: any) {
      console.error('Lỗi khi xuất PDF:', err);
      alert('Không thể tạo file bản in PDF: ' + err.message);
    }
  };

  const printProfessionalReport = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Vui lòng cấp quyền mở tab mới (Pop-up block) trên trình duyệt để trích xuất báo cáo in ấn sếp nhé!');
      return;
    }

    const htmlContent = `
      <html>
        <head>
          <title>Báo cáo KPI Tín Dân Company</title>
          <link href="https://fonts.googleapis.com/css2?family=Inter:wght@455;500;600;700;800&display=swap" rel="stylesheet">
          <script src="https://cdn.tailwindcss.com"></script>
          <style>
            body { font-family: 'Inter', sans-serif; }
            @media print {
              .no-print { display: none !important; }
              body { background-color: white !important; color: black !important; padding: 0 !important; }
              .shadow-sm, .glass-card { box-shadow: none !important; border: 1px solid #e2e8f0 !important; }
            }
          </style>
        </head>
        <body class="bg-slate-100 p-8 text-slate-800">
          <div class="max-w-4xl mx-auto bg-white p-8 md:p-12 rounded-3xl shadow-xl border border-slate-200">
            <!-- Header -->
            <div class="flex justify-between items-start border-b-2 border-emerald-500 pb-6 mb-8">
              <div>
                <p class="text-[9px] font-extrabold text-emerald-600 uppercase tracking-widest">HỆ THỐNG ĐIỀU HÀNH DOANH NGHIỆP TRỰC TUYẾN • TÍN DÂN OS v1.0</p>
                <h1 class="text-xl md:text-2xl font-black text-slate-900 mt-1">CÔNG TY TNHH THƯƠNG MẠI VÀ IN SẤY TÍN DÂN</h1>
                <p class="text-xs text-slate-500 mt-1">Đường ống in ấn: decal cuộn, tem nhãn sấy UV Vivian cao cấp</p>
                <p class="text-xs text-slate-400">Trình ký trực tiếp: CEO Trần Tuấn Anh</p>
              </div>
              <div class="text-right">
                <span class="inline-block bg-teal-100 text-teal-900 text-[10px] font-extrabold px-3 py-1 rounded-md uppercase tracking-wider">KPI QUẢN TRỊ HIỆU NĂNG</span>
                <p class="text-xs text-slate-400 mt-2.5">Ngày xuất bản: ${new Date().toLocaleDateString('vi-VN')}</p>
                <p class="text-[10px] text-slate-500 font-mono">ID: TD-KPI-0626</p>
              </div>
            </div>

            <!-- Title -->
            <div class="text-center mb-8">
              <h2 class="text-xl font-black text-slate-900 tracking-tight uppercase">BẢNG TỔNG KẾT & XẾP HẠNG KPI THÀNH VIÊN DOANH NGHIỆP</h2>
              <p class="text-xs text-slate-500 mt-1">Chu kỳ lưu trữ: Tháng ${kpis[0]?.month || '06/2026'}</p>
            </div>

            <!-- Table of results -->
            <div class="border border-slate-200 rounded-2xl overflow-hidden mb-8 shadow-sm">
              <table class="w-full text-left border-collapse">
                <thead>
                  <tr class="bg-gradient-to-r from-emerald-650 to-emerald-600 text-white text-xs font-bold uppercase">
                    <th class="p-3 bg-emerald-600">STT</th>
                    <th class="p-3 bg-emerald-600">Họ và Tên thành viên</th>
                    <th class="p-3 bg-emerald-600">Phòng Ban thực thi</th>
                    <th class="p-3 bg-emerald-600 text-center">Tổng Việc</th>
                    <th class="p-3 bg-emerald-600 text-center">Đã Xong</th>
                    <th class="p-3 bg-emerald-600 text-center">Trễ Hạn</th>
                    <th class="p-3 bg-emerald-650 text-center bg-emerald-700">KPI Score</th>
                    <th class="p-3 bg-emerald-600">Xếp Hạng & Nhật Ký Ghi Chú</th>
                  </tr>
                </thead>
                <tbody class="text-xs divide-y divide-slate-150">
                  ${kpis.map((k, index) => {
                    const ratio = Math.round(((k.completedTasks || 0) / (k.totalTasks || 1)) * 100);
                    const starCount = Math.max(1, Math.min(5, Math.round((ratio / 100) * 5)));
                    const starsStr = "★".repeat(starCount) + "☆".repeat(5 - starCount);
                    return `
                      <tr class="hover:bg-slate-50">
                        <td class="p-3 font-mono font-bold text-slate-400 text-center">${index + 1}</td>
                        <td class="p-3 font-bold text-slate-900">${k.employeeName}</td>
                        <td class="p-3">${k.department}</td>
                        <td class="p-3 text-center font-bold text-slate-700">${k.totalTasks}</td>
                        <td class="p-3 text-center text-blue-600 font-bold">${k.completedTasks}</td>
                        <td class="p-3 text-center text-rose-500 font-bold">${k.overdueTasks}</td>
                        <td class="p-3 text-center text-emerald-600 font-extrabold text-sm bg-emerald-50">${k.kpiScore}đ</td>
                        <td class="p-3">
                          <div class="text-amber-500 font-bold text-xs mb-0.5" style="letter-spacing: 1px">${starsStr}</div>
                          <p class="text-slate-500 italic leading-relaxed text-[10.5px]">${k.notes || 'Công suất ổn định, đóng góp tốt.'}</p>
                        </td>
                      </tr>
                    `;
                  }).join('')}
                </tbody>
              </table>
            </div>

            <!-- Performance insights summary -->
            <div class="bg-slate-50 p-4 rounded-xl border border-slate-100 mb-8 text-xs leading-relaxed text-slate-600">
              <span class="font-bold text-slate-800 block mb-1">💡 ĐÁNH GIÁ ĐIỂM CHUNG TỪ HỆ THỐNG TRÍ TUỆ NHÂN TẠO TIN DAN OS:</span>
              Hoàn thành kế hoạch xuất sắc trong kỳ gồm các nhân sự thực thi thuộc bộ phận sản xuất in sấy UV decal. Các chỉ số hiệu suất của cán bộ nhân viên đã được đồng bộ 100% lên mây dữ liệu đám mây Firestore, đảm bảo toàn bộ hệ thống minh bạch dữ liệu, phân rã thông số, hạn chế sai sót.
            </div>

            <!-- Signature block -->
            <div class="grid grid-cols-2 gap-12 mt-12 pt-12 border-t border-slate-150">
              <div class="text-center text-xs">
                <p class="text-slate-400">Người đại diện kiểm tra</p>
                <p class="font-bold text-slate-700 mt-16">${currentUser.name}</p>
                <p class="text-[10px] text-slate-400">Tín Dân Company Ltd.</p>
              </div>
              <div class="text-center text-xs">
                <p class="text-slate-400">Đại diện Quản lý tối cao công nhận</p>
                <span class="inline-block bg-teal-50 px-2.5 py-0.5 rounded text-emerald-700 font-bold text-[9px] mt-2 mb-1">CHỮ KÝ SỐ CO-SIGNED</span>
                <p class="font-extrabold text-slate-900 mt-10">Trần Tuấn Anh</p>
                <p class="text-[10px] text-slate-400">Giám đốc Điều hành Công ty</p>
              </div>
            </div>

            <!-- Print Actions Row -->
            <div class="no-print mt-12 flex justify-center gap-3">
              <button 
                onclick="window.print()" 
                class="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-2.5 px-8 rounded-xl text-xs transition-all shadow-lg shadow-emerald-500/20 uppercase tracking-wider flex items-center gap-1.5"
              >
                🖨️ IN BIỂU MẪU / LƯU PDF TIẾNG VIỆT CÓ DẤU
              </button>
              <button 
                onclick="window.close()" 
                class="bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold py-2.5 px-6 rounded-xl text-xs transition-all"
              >
                Đóng Trình in
              </button>
            </div>
          </div>
        </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };


  const triggerAddBonus = (kpiId: string) => {
    let changedKpi: KPIs | null = null;
    const updated = kpis.map(k => {
      if (k.id === kpiId) {
        const nextScore = (k.kpiScore || 0) + awardScore;
        const note = `Được cộng thưởng +${awardScore}đ bởi ${currentUser.name}. Lý do: ${bonusComment || 'Đóng góp xuất sắc cho dây chuyền.'}`;
        
        onAddNotification(
          'Thưởng điểm KPI thần tốc',
          `Cán bộ ${k.employeeName} được thưởng +${awardScore}đ KPI. ${bonusComment}`,
          'system'
        );

        changedKpi = { 
          ...k, 
          kpiScore: nextScore,
          notes: note
        };
        return changedKpi;
      }
      return k;
    });

    setKpis(updated);
    if (changedKpi) {
      DB.saveKPI(changedKpi);
    }
    
    setSelectedKpiId(null);
    setBonusComment('');
  };

  // Add new KPI record
  const handleAddNewKpi = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKpiUser) {
      alert('Chưa cấu định nhân sự sếp ơi!');
      return;
    }

    const item: KPIs = {
      id: 'kpi_' + Date.now(),
      employeeName: newKpiUser,
      department: newKpiDept,
      month: newKpiMonth,
      totalTasks: newKpiTotal,
      completedTasks: newKpiCompleted,
      overdueTasks: newKpiOverdue,
      kpiScore: newKpiScore,
      weeklyProgress: [
        Math.min(100, Math.round((newKpiCompleted / (newKpiTotal || 1)) * 100 * 0.4)),
        Math.min(100, Math.round((newKpiCompleted / (newKpiTotal || 1)) * 100 * 0.7)),
        Math.min(100, Math.round((newKpiCompleted / (newKpiTotal || 1)) * 100 * 0.9)),
        Math.min(100, Math.round((newKpiCompleted / (newKpiTotal || 1)) * 100))
      ],
      notes: newKpiNotes || 'Thiết lập chỉ số hiệu suất phòng ban mới.'
    };

    const updated = [item, ...kpis];
    setKpis(updated);
    DB.saveKPI(item);
    setShowAddKpiModal(false);

    onAddNotification(
      'Khởi tạo KPI thành viên',
      `Đã thêm chỉ số KPI tháng ${newKpiMonth} cho ${newKpiUser}.`,
      'system'
    );
  };

  // Delete KPI record
  const handleDeleteKpi = (id: string, name: string) => {
    if (!window.confirm(`Sếp có chắc chắn muốn xóa bản ghi KPI của cán bộ "${name}"? Thao tác này không thể thu hồi!`)) {
      return;
    }
    const updated = kpis.filter(k => k.id !== id);
    setKpis(updated);
    DB.deleteKPI(id);

    onAddNotification(
      'Xóa bản ghi KPI',
      `Hệ thống đã loại bỏ bản ghi hiệu suất của cán bộ ${name}.`,
      'system'
    );
  };

  // Handle direct Excel spreadsheet cell modification
  const handleCellChange = (kpiId: string, field: keyof KPIs, value: any) => {
    let cleanedVal = value;
    if (['totalTasks', 'completedTasks', 'overdueTasks', 'kpiScore'].includes(field as string)) {
      cleanedVal = parseInt(value) || 0;
    }
    let changedKpi: KPIs | null = null;
    const updated = kpis.map(k => {
      if (k.id === kpiId) {
        const item = { ...k, [field]: cleanedVal };
        // Recalculate weekly progress if tasks changed
        if (field === 'completedTasks' || field === 'totalTasks') {
          const ratio = Math.round(((item.completedTasks ?? 0) / (item.totalTasks || 1)) * 100);
          item.weeklyProgress = [
            Math.round(ratio * 0.4),
            Math.round(ratio * 0.7),
            Math.round(ratio * 0.9),
            ratio
          ];
        }
        changedKpi = item;
        return item;
      }
      return k;
    });
    setKpis(updated);
    if (changedKpi) {
      DB.saveKPI(changedKpi);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-4 md:p-6 lg:p-8 font-sans">
      
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white font-display uppercase tracking-tight flex items-center gap-2">
            <Award className="w-6 h-6 text-emerald-600" />
            <span>Chỉ số Hiệu suất & Xếp hạng KPI</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Quản lý xếp hạng, thêm/xóa chỉ số và điều chỉnh trực tiếp trên bảng Excel mô phỏng để tối ưu hóa hiệu năng phòng ban.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {hasKpiAdminAccess && (
            <button
              type="button"
              onClick={() => setShowAddKpiModal(true)}
              className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md shadow-blue-500/20"
            >
              <Plus className="w-4 h-4" />
              Thêm KPI Nhân sự
            </button>
          )}

          {hasKpiAdminAccess && (
            <>
              <button
                type="button"
                onClick={exportToExcel}
                className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md shadow-emerald-500/20"
              >
                <FileSpreadsheet className="w-4 h-4" />
                Xuất Excel
              </button>
              
              <button
                type="button"
                onClick={exportToPDF}
                className="flex items-center gap-2 bg-rose-600 hover:bg-rose-700 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md shadow-rose-500/20"
              >
                <FileDown className="w-4 h-4" />
                Tải PDF
              </button>

              <button
                type="button"
                onClick={printProfessionalReport}
                className="flex items-center gap-2 bg-slate-800 hover:bg-slate-900 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md shadow-slate-900/20"
              >
                <span>🖨️ In ký duyệt (Có dấu)</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Corporate benchmark banners */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-r from-emerald-500 to-emerald-600 text-white p-4 rounded-xl shadow-sm flex items-center justify-between">
          <div>
            <span className="text-[10px] text-emerald-100 uppercase tracking-widest font-bold">Hoàn thành nhiều nhất</span>
            <span className="text-lg font-bold block mt-1">Trần Minh Đức</span>
            <span className="text-[10px] text-emerald-100">Phòng Kỹ Thuật • Tỉ lệ 95%</span>
          </div>
          <Award className="w-8 h-8 opacity-80" />
        </div>

        <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-4 rounded-xl shadow-sm flex items-center justify-between">
          <div>
            <span className="text-[10px] text-blue-100 uppercase tracking-widest font-bold">Ngôi sao đang lên</span>
            <span className="text-lg font-bold block mt-1">Nguyễn Văn Nam</span>
            <span className="text-[10px] text-blue-100">Phòng Marketing • Tích lũy 145đ</span>
          </div>
          <TrendingUp className="w-8 h-8 opacity-80" />
        </div>

        <div className="bg-gradient-to-r from-purple-500 to-purple-600 text-white p-4 rounded-xl shadow-sm flex items-center justify-between">
          <div>
            <span className="text-[10px] text-purple-100 uppercase tracking-widest font-bold">Thưởng tổng kết năm</span>
            <span className="text-lg font-bold block mt-1">Công suất ổn định</span>
            <span className="text-[10px] text-purple-100">Trung bình đạt 4.2 sao</span>
          </div>
          <Star className="w-8 h-8 opacity-80 fill-purple-200" />
        </div>
      </div>

      {/* 🟢 EXCEL LIVE GRID PREVIEW VIEW & CONTROL BOX */}
      <div className="glass-card rounded-2xl overflow-hidden border border-emerald-500/20 shadow-lg">
        <div className="p-4 bg-gradient-to-r from-emerald-800 to-emerald-900 text-white flex justify-between items-center">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-emerald-300" />
            <div>
              <span className="font-bold text-xs uppercase tracking-wider block">BẢNG TÍNH LỢI THẾ EXCEL HOẠT ĐỘNG (PREVIEW & SỬA TRỰC TIẾP)</span>
              <span className="text-[10px] text-emerald-200">Sếp nhấp trực tiếp vào ô bất kỳ dưới đây để điều chỉnh dữ liệu và cấu cục. File xuất Excel sẽ cập nhật lập tức!</span>
            </div>
          </div>
          <span className="text-[10px] bg-emerald-700/50 px-2 py-0.5 rounded font-mono font-bold uppercase">MODE: REALTIME EDIT</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse table-fixed min-w-[900px] text-xs font-mono">
            <thead>
              <tr className="bg-slate-100 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 text-slate-500 font-bold text-center">
                <th className="p-2 border-r border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-950 w-12">#</th>
                <th className="p-2 border-r border-slate-200 dark:border-slate-800 bg-emerald-500/10 text-emerald-800 dark:text-emerald-400 w-48">Họ và tên [A]</th>
                <th className="p-2 border-r border-slate-200 dark:border-slate-800 w-36">Phòng ban [B]</th>
                <th className="p-2 border-r border-slate-200 dark:border-slate-800 w-24">Tháng [C]</th>
                <th className="p-2 border-r border-slate-200 dark:border-slate-800 w-24">Tổng Việc [D]</th>
                <th className="p-2 border-r border-slate-200 dark:border-slate-800 w-24">Đã Xong [E]</th>
                <th className="p-2 border-r border-slate-200 dark:border-slate-800 w-24">Quá Hạn [F]</th>
                <th className="p-2 border-r border-slate-200 dark:border-slate-800 text-emerald-700 w-24">Điểm KPI [G]</th>
                <th className="p-2 w-auto">Ghi chú & Đánh giá phân phối [H]</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-150 dark:divide-slate-850">
              {kpis.map((k, index) => (
                <tr key={k.id} className="hover:bg-emerald-500/5 dark:hover:bg-emerald-500/5 transition-colors align-middle">
                  <td className="p-1 border-r border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950/60 text-center text-[11px] font-bold text-slate-400">
                    {index + 1}
                  </td>
                  
                  {/* Employee Name cell */}
                  <td className="p-1 border-r border-slate-200 dark:border-slate-800">
                    <input 
                      type="text"
                      value={k.employeeName}
                      onChange={(e) => handleCellChange(k.id, 'employeeName', e.target.value)}
                      className="w-full bg-transparent hover:bg-white/10 focus:bg-white focus:text-slate-950 dark:focus:bg-slate-800 dark:focus:text-white px-2 py-1 rounded text-slate-900 dark:text-slate-100 outline-none font-bold"
                    />
                  </td>

                  {/* Department cell */}
                  <td className="p-1 border-r border-slate-200 dark:border-slate-800">
                    <select
                      value={k.department}
                      onChange={(e) => handleCellChange(k.id, 'department', e.target.value)}
                      className="w-full bg-transparent hover:bg-white/10 focus:bg-white focus:text-slate-950 dark:focus:bg-slate-800 dark:focus:text-white px-2 py-1 rounded outline-none"
                    >
                      {Object.values(Department).map(d => (
                        <option key={d} value={d}>{d}</option>
                      ))}
                    </select>
                  </td>

                  {/* Month cell */}
                  <td className="p-1 border-r border-slate-200 dark:border-slate-800 text-center">
                    <input 
                      type="text"
                      value={k.month}
                      onChange={(e) => handleCellChange(k.id, 'month', e.target.value)}
                      className="w-full bg-transparent text-center hover:bg-white/10 focus:bg-white focus:text-slate-950 dark:focus:bg-slate-800 dark:focus:text-white px-1 py-1 rounded outline-none"
                    />
                  </td>

                  {/* Total Tasks cell */}
                  <td className="p-1 border-r border-slate-200 dark:border-slate-800 text-center">
                    <input 
                      type="number"
                      value={k.totalTasks}
                      onChange={(e) => handleCellChange(k.id, 'totalTasks', e.target.value)}
                      className="w-full bg-transparent text-center hover:bg-white/10 focus:bg-white focus:text-slate-950 dark:focus:bg-slate-800 dark:focus:text-white px-1 py-1 rounded outline-none font-bold"
                    />
                  </td>

                  {/* Completed Tasks cell */}
                  <td className="p-1 border-r border-slate-200 dark:border-slate-800 text-center">
                    <input 
                      type="number"
                      value={k.completedTasks}
                      onChange={(e) => handleCellChange(k.id, 'completedTasks', e.target.value)}
                      className="w-full bg-transparent text-center hover:bg-white/10 focus:bg-white focus:text-slate-950 dark:focus:bg-slate-800 dark:focus:text-white px-1 py-1 rounded outline-none font-bold text-blue-600 dark:text-blue-400"
                    />
                  </td>

                  {/* Overdue Tasks cell */}
                  <td className="p-1 border-r border-slate-200 dark:border-slate-800 text-center">
                    <input 
                      type="number"
                      value={k.overdueTasks}
                      onChange={(e) => handleCellChange(k.id, 'overdueTasks', e.target.value)}
                      className="w-full bg-transparent text-center hover:bg-white/10 focus:bg-white focus:text-slate-950 dark:focus:bg-slate-800 dark:focus:text-white px-1 py-1 rounded outline-none font-bold text-rose-500"
                    />
                  </td>

                  {/* KPI Score cell */}
                  <td className="p-1 border-r border-slate-200 dark:border-slate-800 text-center bg-emerald-500/5">
                    <input 
                      type="number"
                      value={k.kpiScore}
                      onChange={(e) => handleCellChange(k.id, 'kpiScore', e.target.value)}
                      className="w-full bg-transparent text-center hover:bg-white/10 focus:bg-white focus:text-slate-950 dark:focus:bg-slate-800 dark:focus:text-white px-1 py-1 rounded outline-none font-bold text-emerald-600 dark:text-emerald-400"
                    />
                  </td>

                  {/* Notes cell */}
                  <td className="p-1">
                    <input 
                      type="text"
                      value={k.notes || ''}
                      onChange={(e) => handleCellChange(k.id, 'notes', e.target.value)}
                      className="w-full bg-transparent hover:bg-white/10 focus:bg-white focus:text-slate-950 dark:focus:bg-slate-800 dark:focus:text-white px-2 py-1 rounded outline-none italic font-sans"
                      placeholder="Nhập ghi chú đánh giá..."
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* KPI Listing table card board (Standard dashboard view with delete features options) */}
      <div className="glass-card rounded-2xl overflow-hidden text-xs shadow-lg">
        <div className="p-4 border-b border-white/5 dark:border-white/5 flex justify-between items-center bg-white/5 dark:bg-black/20">
          <span className="font-bold text-slate-800 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
            <Table className="w-4 h-4 text-slate-500" />
            <span>BẢNG PHÂN CẤP KPI TÍN DÂN COMPANY (HÀNH ĐỘNG HỆ THỐNG)</span>
          </span>
          <span className="text-[10px] text-slate-400 font-bold font-mono">Tháng hiện tại: Tháng 06/2026</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-100/50 dark:bg-slate-900 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-150 dark:border-slate-800">
                <th className="p-4">Nhân sự thực thi</th>
                <th className="p-4">Phòng ban</th>
                <th className="p-4 text-center">Hoàn thành</th>
                <th className="p-4 text-center">Trễ hạn</th>
                <th className="p-4">Xếp hạng Star</th>
                <th className="p-4">Nhật ký phần thưởng</th>
                <th className="p-4 text-center">Hiện tại KPI</th>
                <th className="p-4 text-center">Hành động</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-150 dark:divide-slate-800">
              {kpis.map((k) => {
                const ratio = Math.round(((k.completedTasks ?? 0) / (k.totalTasks || 1)) * 105 / 105 * 100);
                const starRating = Math.max(1, Math.min(5, Math.round((ratio / 100) * 5)));

                return (
                  <tr key={k.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-850/30 text-slate-700 dark:text-slate-300">
                    <td className="p-4 font-semibold text-slate-900 dark:text-white">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-bold text-[10px] flex items-center justify-center">
                          {(k.employeeName || 'N').charAt(0)}
                        </div>
                        <span>{k.employeeName || 'N/A'}</span>
                      </div>
                    </td>
                    <td className="p-4">{k.department || 'N/A'}</td>
                    <td className="p-4 text-center">
                      <span className="font-bold font-mono text-slate-900 dark:text-white">{k.completedTasks ?? 0}</span>
                      <span className="text-[10px] text-slate-400 font-mono">/{k.totalTasks ?? 0}</span>
                    </td>
                    <td className="p-4 text-center text-rose-500 font-bold font-mono">{k.overdueTasks ?? 0}</td>
                    
                    {/* Stars render */}
                    <td className="p-4">
                      <div className="flex text-amber-500 gap-0.5">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star 
                            key={i} 
                            className={`w-3.5 h-3.5 ${i < starRating ? 'fill-yellow-400 text-yellow-400' : 'text-slate-200'}`} 
                          />
                        ))}
                      </div>
                    </td>

                    <td className="p-4 text-slate-400 italic max-w-xs truncate" title={k.notes || ''}>
                      {k.notes || 'Công suất ổn định'}
                    </td>

                    <td className="p-4 text-center text-emerald-600 dark:text-emerald-400 font-bold font-mono text-xs">
                      {k.kpiScore ?? 0}đ
                    </td>

                    <td className="p-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        {hasKpiAdminAccess ? (
                          <>
                            <button
                              type="button"
                              onClick={() => setSelectedKpiId(k.id)}
                              className="px-2 py-1 bg-blue-50 hover:bg-blue-600 text-blue-600 hover:text-white border border-blue-200 rounded-lg text-[10px] font-bold uppercase transition-all"
                            >
                              Thưởng Điểm
                            </button>
                            <button
                              onClick={() => handleDeleteKpi(k.id, k.employeeName || 'N/A')}
                              title="Xóa đánh giá KPI"
                              className="p-1.5 text-rose-650 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors border-none"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </>
                        ) : (
                          <span className="text-slate-400 text-[10px]">Chỉ Admin</span>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 🔴 OVERLAY DIALOG FOR ADDING NEW KPI */}
      {showAddKpiModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50">
          <form onSubmit={handleAddNewKpi} className="glass-card w-full max-w-sm rounded-2xl overflow-hidden block shadow-2xl animate-fade-in text-xs">
            <div className="p-4 border-b border-white/5 bg-slate-50 dark:bg-slate-900 text-slate-700 dark:text-slate-300 font-bold text-xs uppercase flex justify-between items-center">
              <span>Thêm chấm KPI mới theo phòng ban</span>
              <button 
                type="button" 
                onClick={() => setShowAddKpiModal(false)}
                className="text-slate-400 hover:text-slate-600 text-sm"
              >✕</button>
            </div>

            <div className="p-5 space-y-4">
              {/* Department Option */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">1. Chọn phòng ban xưởng</label>
                <select
                  value={newKpiDept}
                  onChange={(e) => setNewKpiDept(e.target.value as Department)}
                  className="w-full glass-dropdown text-xs py-2 px-3 rounded-lg font-bold font-sans"
                >
                  {Object.values(Department).map(d => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>

              {/* Scope assigned users dropdown based on department */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">2. Nhân sự trực thuộc phòng can</label>
                {allUsers.filter(u => u.department === newKpiDept).length === 0 ? (
                  <div className="text-rose-500 py-1 font-semibold italic">
                    ⚠ Có lỗi: Không có nhân viên nào trực thuộc bộ phận này! Hãy tạo tài khoản nhân sự trước.
                  </div>
                ) : (
                  <select
                    value={newKpiUser}
                    onChange={(e) => setNewKpiUser(e.target.value)}
                    className="w-full glass-dropdown text-xs py-2 px-3 rounded-lg font-bold font-sans"
                  >
                    {allUsers.filter(u => u.department === newKpiDept).map(u => (
                      <option key={u.id} value={u.name}>{u.name} ({u.email})</option>
                    ))}
                  </select>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Tháng lưu kpi</label>
                  <input
                    type="text"
                    required
                    value={newKpiMonth}
                    onChange={(e) => setNewKpiMonth(e.target.value)}
                    placeholder="VD: 06/2026"
                    className="w-full glass-input text-xs py-2 px-3 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Điểm KPI mặc định</label>
                  <input
                    type="number"
                    required
                    value={newKpiScore}
                    onChange={(e) => setNewKpiScore(parseInt(e.target.value) || 0)}
                    className="w-full glass-input text-xs py-2 px-3 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[9.5px] font-semibold text-slate-400 mb-1">Tổng việc</label>
                  <input
                    type="number"
                    required
                    value={newKpiTotal}
                    onChange={(e) => setNewKpiTotal(parseInt(e.target.value) || 0)}
                    className="w-full glass-input text-[11px] py-1.5 px-2 rounded-lg text-center"
                  />
                </div>
                <div>
                  <label className="block text-[9.5px] font-semibold text-slate-400 mb-1">Đã xong</label>
                  <input
                    type="number"
                    required
                    value={newKpiCompleted}
                    onChange={(e) => setNewKpiCompleted(parseInt(e.target.value) || 0)}
                    className="w-full glass-input text-[11px] py-1.5 px-2 rounded-lg text-center text-blue-500 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[9.5px] font-semibold text-slate-400 mb-1">Trễ hạn</label>
                  <input
                    type="number"
                    required
                    value={newKpiOverdue}
                    onChange={(e) => setNewKpiOverdue(parseInt(e.target.value) || 0)}
                    className="w-full glass-input text-[11px] py-1.5 px-2 rounded-lg text-center text-rose-500 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Ghi chú & Đánh giá hiệu suất ban đầu</label>
                <input
                  type="text"
                  value={newKpiNotes}
                  onChange={(e) => setNewKpiNotes(e.target.value)}
                  placeholder="Vd: Bản in sấy UV tem mác Vivian cực tốt..."
                  className="w-full glass-input text-xs py-2 px-3 rounded-lg"
                />
              </div>
            </div>

            <div className="p-3 border-t border-white/5 bg-slate-50 dark:bg-slate-900/40 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setShowAddKpiModal(false)}
                className="px-3 py-1.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-350 rounded-lg font-medium"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-750 text-white rounded-lg font-bold uppercase"
              >
                Xác nhận thêm
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Bonus Award overlay pop up */}
      {selectedKpiId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50">
          <div className="glass-card w-full max-w-sm rounded-2xl overflow-hidden block shadow-2xl">
            <div className="p-4 border-b border-white/5 bg-white/5 dark:bg-black/20 font-bold text-xs uppercase text-slate-700 dark:text-slate-200">
              Mã thưởng KPI cho cán bộ: {kpis.find(k => k.id === selectedKpiId)?.employeeName}
            </div>

            <div className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5">Số điểm muốn cộng thưởng</label>
                <select
                  value={awardScore}
                  onChange={(e) => setAwardScore(parseInt(e.target.value))}
                  className="w-full glass-dropdown text-xs py-2 px-3 rounded-lg font-bold font-sans"
                >
                  <option value={5}>+5đ (Hoàn thành tốt lô decal)</option>
                  <option value={10}>+10đ (Tăng ca sửa máy UV)</option>
                  <option value={20}>+20đ (Lãnh đạo nhóm xuất sắc)</option>
                  <option value={50}>+50đ (Ký hợp đồng in Tem Vivian lớn)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-550 dark:text-slate-400 mb-1.5">Lý do thưởng phạt</label>
                <input
                  type="text"
                  required
                  value={bonusComment}
                  onChange={(e) => setBonusComment(e.target.value)}
                  placeholder="Vd: Sửa bo mạch máy cắt nhãn đêm thứ 3..."
                  className="w-full glass-input rounded-lg text-xs py-2 px-3 focus:outline-none"
                />
              </div>
            </div>

            <div className="p-3 border-t border-white/5 bg-white/5 dark:bg-black/20 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setSelectedKpiId(null)}
                className="px-3 py-1.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-350 rounded-lg"
              >
                Hủy bỏ
              </button>
              <button
                type="button"
                onClick={() => triggerAddBonus(selectedKpiId)}
                className="px-4 py-1.5 bg-emerald-600 text-white rounded-lg hover:bg-emerald-750 font-bold"
              >
                Phê duyệt cộng
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
