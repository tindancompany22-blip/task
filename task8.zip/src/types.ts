export enum Department {
  MARKETING = 'Marketing',
  SALE = 'Sale',
  KY_THUAT = 'Kỹ thuật',
  KHO = 'Kho',
  CSKH = 'CSKH',
  KE_TOAN = 'Kế toán',
  ADMIN = 'Admin'
}

export enum UserRole {
  ADMIN = 'Admin',
  MANAGER = 'Manager',
  EMPLOYEE = 'Employee'
}

export interface Task {
  id: string;
  title: string;
  description: string;
  status: 'todo' | 'in_progress' | 'done' | 'backlog';
  priority: 'low' | 'medium' | 'high' | 'critical';
  dueDate: string;
  assignedTo: string;
  projectId: string;
  progress: number; // 0 - 100
  $id?: string;
  $createdAt?: string;

  // Rebuilt Enterprise fields
  creator?: string;
  department?: string;
  labels?: string[];
  start_date?: string;
  estimated_hours?: number;
  actual_hours?: number;
  progress_percent?: number;
  dependencies?: string[]; // Task IDs
  subtasks?: { id: string; title: string; done: boolean }[];
  attachments?: { id: string; name: string; url: string; size?: string }[];
  comments?: { id: string; userName: string; content: string; createdAt: string }[];
  mentions?: string[];
  activity_logs?: { id: string; action: string; performedBy: string; timestamp: string }[];
  AI_score?: number;
  KPI_weight?: number;
  KPI_confirmed?: boolean;
  SLA_level?: 'low' | 'medium' | 'high' | 'critical';
  workflow_stage?: string;
  actualResult?: string;
  followers?: string[];
  kpiScore?: number;
  planMonth?: string;
  planWeek?: string;
  createdAt?: string;
  createdBy?: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  manager: string;
  startDate: string;
  endDate: string;
  status: 'planning' | 'ongoing' | 'completed' | 'on_hold' | 'active' | 'on-hold' | string;
  department?: string;
  progress?: number;
  $id?: string;
}

export interface KPIs {
  id: string;
  name?: string;
  target?: number;
  current?: number;
  unit?: string;
  period?: string;
  employeeName?: string;
  department?: string;
  month?: string;
  totalTasks?: number;
  completedTasks?: number;
  overdueTasks?: number;
  kpiScore?: number;
  weeklyProgress?: number[];
  notes?: string;
  $id?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  avatar?: string;
  password?: string;
  permissions?: string[]; // Allowed tab IDs
  department?: string;
  status?: 'active' | 'locked';
  $id?: string;
}

export interface TaskActivityLog {
  id: string;
  taskId: string;
  action: string;
  performedBy: string;
  timestamp: string;
  details?: string;
  $id?: string;
}

export interface EmployeeWorkload {
  id: string;
  employeeId: string;
  employeeName: string;
  allocatedHours: number;
  maxHours: number;
  taskCount: number;
  $id?: string;
}

export interface TaskRiskScore {
  id: string;
  taskId: string;
  riskScore: number; // 1-100
  riskFactor: string;
  mitigationStrategyName: string;
  $id?: string;
}

export interface ZaloOAConfig {
  id: string;
  name: string;
  oaId: string;
  accessToken: string;
  refreshToken: string;
  expiresAt: string;
  status: 'active' | 'expired' | 'disconnected';
  avatarUrl?: string;
  $id?: string;
}

export interface ZaloWebhookMessage {
  id: string;
  messageId: string;
  oaId: string;
  senderId: string;
  senderName: string;
  messageText: string;
  timestamp: string;
  eventType: string; // user_send_text, user_seen, etc.
  $id?: string;
}

export interface Lead {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  age?: number;
  rating?: number; // 1-5
  description?: string;
  address?: string;
  status: 'new' | 'contacted' | 'interested' | 'not_interested' | 'closed' | 'deal' | string;
  interactionHistoryCount?: number;
  lastInteractionDate?: string;
  demand?: string;
  referrerPage?: string;
  timestamp?: string;
  $id?: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success' | 'alert';
  read: boolean;
  timestamp: string;
  $id?: string;
}
