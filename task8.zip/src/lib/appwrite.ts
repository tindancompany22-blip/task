import { Client, Account, Databases, Storage, Query } from 'appwrite';

const client = new Client();

const endpointRaw = (import.meta as any).env?.VITE_APPWRITE_ENDPOINT || 'https://fra.cloud.appwrite.io/v1';
const projectIdRaw = (import.meta as any).env?.VITE_APPWRITE_PROJECT_ID || '6a2bc7f1002d42a52ac0';
export const DATABASE_ID = ((import.meta as any).env?.VITE_APPWRITE_DATABASE_ID || '6a2bcb1e000ec6c8bb28').replace(/^['"]|["']$/g, '').trim();

const endpoint = endpointRaw.replace(/^['"]|["']$/g, '').trim();
const projectId = projectIdRaw.replace(/^['"]|["']$/g, '').trim();

console.log('[Appwrite configuration URL & project checked]', { endpoint, projectId, DATABASE_ID });

client
  .setEndpoint(endpoint)
  .setProject(projectId);

export const account = new Account(client);
export const databases = new Databases(client);
export const realtime = client; // Appwrite subscribing API is exposed directly on Client
export const storage = new Storage(client);

// Helper to check if server is reachable / configured
export const checkAppwriteConnection = async (): Promise<boolean> => {
  try {
    // Avoid 'csacac' collection test, which is a guaranteed 404, throwing noise in console
    await databases.listDocuments(DATABASE_ID, 'tasks', [Query.limit(1)]);
    console.log('[APPWRITE CONNECTION] Connected successfully. Databases structure online.');
    return true;
  } catch (err: any) {
    console.warn('[APPWRITE CONNECTION] Query check:', err?.message || err);
    // If the error is not network related (e.g. 404 collection not found, or 401 unauthorized), the server is still perfectly reachable
    if (
      err?.type === 'general_rate_limit_exceeded' || 
      err?.type === 'user_unauthorized' || 
      err?.code === 401 || 
      err?.code === 403 || 
      err?.code === 404
    ) {
      console.log('[APPWRITE CONNECTION] Server is reachable (received response from Appwrite Cloud).');
      return true;
    }
    return false;
  }
};

export { client };
